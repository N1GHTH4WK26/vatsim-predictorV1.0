import requests
import sqlite3
import time
from datetime import datetime, timedelta, timezone

# --- CONFIGURATION ---
DB_PATH = "vatsim_coverage.db"
URL = "https://data.vatsim.net/v3/vatsim-data.json"

def init_db():
    """Initializes the SQLite database and creates the required tables."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Table to track global data capture intervals
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS global_samples (
            timestamp TEXT PRIMARY KEY,
            day_of_week INTEGER,
            hour_of_day INTEGER
        )
    ''')
    
    # Table to track specific controller presence snapshots
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS controller_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            callsign TEXT,
            day_of_week INTEGER,
            hour_of_day INTEGER,
            FOREIGN KEY(timestamp) REFERENCES global_samples(timestamp)
        )
    ''')
    
    conn.commit()
    conn.close()

def fetch_and_store():
    """Fetches the live VATSIM JSON feed and logs active ATC positions."""
    try:
        response = requests.get(URL, timeout=15)
        if response.status_code != 200:
            print(f"[{datetime.now(timezone.utc)}] Failed to fetch VATSIM data. Status: {response.status_code}")
            return

        data = response.json()
        controllers = data.get("controllers", [])
        
        now = datetime.now(timezone.utc)
        timestamp_str = now.strftime("%Y-%m-%d %H:%M:%S")
        day_of_week = now.weekday()
        hour_of_day = now.hour

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        # Prune data older than 30 days automatically (Rolling Window)
        thirty_days_ago = (now - timedelta(days=30)).strftime('%Y-%m-%d %H:%M:%S')
        cursor.execute("DELETE FROM controller_snapshots WHERE timestamp < ?", (thirty_days_ago,))
        cursor.execute("DELETE FROM global_samples WHERE timestamp < ?", (thirty_days_ago,))

        # Log this specific tracking interval
        try:
            cursor.execute('''
                INSERT INTO global_samples (timestamp, day_of_week, hour_of_day)
                VALUES (?, ?, ?)
            ''', (timestamp_str, day_of_week, hour_of_day))
        except sqlite3.IntegrityError:
            conn.close()
            return

        # Filter out observers and log actual staffing positions
        logged_count = 0
        for ctrl in controllers:
            callsign = ctrl.get("callsign", "").upper()
            facility = ctrl.get("facility", 0)

            # Skip observers (facility 0) and generic automated stations
            if facility == 0 or callsign.endswith("_OBS"):
                continue

            cursor.execute('''
                INSERT INTO controller_snapshots (timestamp, callsign, day_of_week, hour_of_day)
                VALUES (?, ?, ?, ?)
            ''', (timestamp_str, callsign, day_of_week, hour_of_day))
            logged_count += 1

        conn.commit()
        conn.close()
        print(f"[{timestamp_str}] Successfully logged {logged_count} active ATC facilities to analytics database.")

    except Exception as e:
        print(f"[{datetime.now(timezone.utc)}] Aggregator error: {e}")

if __name__ == "__main__":
    print("Initializing VATSIM Analytics Database...")
    init_db()
    
    print("Data aggregator initialized. Running background tracking loops...")
    
    # Continuous logging loop (samples once every 2 minutes)
    while True:
        fetch_and_store()
        time.sleep(120)