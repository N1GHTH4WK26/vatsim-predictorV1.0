import discord
from discord import app_commands
from discord.ext import tasks
import sqlite3
import requests
from datetime import datetime, timedelta, timezone
import os
from dotenv import load_dotenv

# Load hidden environment variables from local .env file
load_dotenv()

# --- CONFIGURATION ---
BOT_TOKEN = os.getenv("DISCORD_TOKEN")
DB_PATH = "vatsim_coverage.db"

def verify_db_structure():
    """Ensures the database file and required tables exist before the bot boots."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS global_samples (
            timestamp TEXT PRIMARY KEY,
            day_of_week INTEGER,
            hour_of_day INTEGER
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS controller_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            callsign TEXT,
            day_of_week INTEGER,
            hour_of_day INTEGER,
            FOREIGN KEY(timestamp) REFERENCES global_samples(timestamp)
        )
    ''')
    # Table to store subscriber user IDs for the daily summary
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS summary_subscriptions (
            user_id INTEGER PRIMARY KEY
        )
    ''')
    conn.commit()
    conn.close()

# Run the structural integrity verification check on initialization
verify_db_structure()

class VATSIMClient(discord.Client):
    def __init__(self):
        intents = discord.Intents.default()
        super().__init__(intents=intents)
        self.tree = app_commands.CommandTree(self)

    async def on_ready(self):
        print(f"Logged in as {self.user.name} (ID: {self.user.id})...")
        try:
            # Syncs slash commands globally across all guilds
            synced = await self.tree.sync()
            print(f"Slash commands synced successfully. Registered {len(synced)} commands.")
        except Exception as e:
            print(f"Failed to sync slash commands: {e}")
        
        # Start background loop upon boot
        if not daily_atc_summary.is_running():
            daily_atc_summary.start()

client = VATSIMClient()

# --- HELPER FUNCTIONS ---
def get_weekday_name(day_int):
    weekdays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    return weekdays[day_int] if 0 <= day_int < 7 else "Unknown"

def get_global_vatsim_prefix(icao: str) -> str:
    """
    Precision worldwide VATSIM routing engine converting any valid ICAO airport 
    code into its controlling enroute Center/FIR prefix exactly as they appear on VATSIM 
    (e.g., ZNY, ZTL, ZDV, CZVR, EDGG, EISN, LFBB).
    """
    icao = icao.upper().strip()
    if not icao or len(icao) < 4:
        return ""

    first = icao[0]
    second = icao[1]

    # --- 1. NORTH AMERICA ---
    if first == 'K':
        # US ARTCC Exceptions Mapping
        us_exceptions = {
            'KJFK': 'ZNY', 'KEWR': 'ZNY', 'KLGA': 'ZNY', 'KISP': 'ZNY', 'KTEB': 'ZNY',
            'KIAD': 'ZDC', 'KDCA': 'ZDC', 'KBWI': 'ZDC', 'KRIC': 'ZDC', 'KPHL': 'ZNY',
            'KATL': 'ZTL', 'KCLT': 'ZTL', 'KORD': 'ZAU', 'KMDW': 'ZAU', 'KMSP': 'ZMP',
            'KDTW': 'ZOB', 'KCVG': 'ZID', 'KDFW': 'ZFW', 'KIAH': 'ZHU', 'KIAH': 'ZHU',
            'KMEM': 'ZME', 'KLAX': 'ZLA', 'KSFO': 'ZOA', 'KSEA': 'ZSE', 'KDEN': 'ZDV',
            'KPHX': 'ZAB', 'KLAS': 'ZLA', 'KSAN': 'ZLA', 'KPDX': 'ZSE', 'KSLC': 'ZLC'
        }
        if icao in us_exceptions:
            return us_exceptions[icao]
        return "Z" + icao[1:3]

    if first == 'C':
        # Canadian Center FIRs (e.g., CZVR, CZYZ, CZQM)
        return "CZ" + second

    if icao.startswith('PA') or icao.startswith('PF') or icao.startswith('PO'):
        return "ZAN"
    if icao.startswith('PH'):
        return "HNL"

    # --- 2. EUROPE ---
    if first == 'E':
        if second in ['D', 'G']:
            # Germany / Langen (e.g., EDGG)
            return icao[:4]
        elif second == 'H':
            # Helsinki (e.g., EFIN)
            return icao[:4]
        elif second == 'I':
            # Italy (e.g., LIMM - though L is more common for Italy FIRs)
            return icao[:4]
        elif second == 'G':
            # United Kingdom (e.g., EGTT, EGPX)
            return icao[:4]
        elif second == 'N':
            # Norway (e.g., ENOR)
            return icao[:4]
        elif second == 'S':
            # Sweden (e.g., ESOS)
            return icao[:4]
        elif second == 'B':
            # Ireland (e.g., EISN)
            return icao[:4]
        return icao[:4]

    if first == 'L':
        # Southern/Central Europe FIRs (e.g., LFBB, LFFF, LIMM, LSAZ)
        return icao[:4]

    # --- 3. OCEANIA ---
    if first == 'Y':
        # Australia / New Zealand FIRs (e.g., YMMM, YBBB, NZAA)
        return icao[:4]
    if first == 'N':
        if second == 'Z':
            return icao[:4]

    # --- 4. ASIA & MIDDLE EAST ---
    if first in ['O', 'R', 'V', 'W']:
        # Middle East, East Asia, South Asia, Maritime Asia (e.g., OMAE, RKSI, VHHH, WIII)
        return icao[:4]

    # --- 5. AFRICA & SOUTH AMERICA ---
    if first in ['F', 'H', 'S']:
        # Africa, South America (e.g., FAOR, SBGR, SAEZ)
        return icao[:4]

    return icao[:4]

# Dynamic Autocomplete Engine linked to your database schema
async def facility_autocomplete(interaction: discord.Interaction, current: str) -> list[app_commands.Choice[str]]:
    choices = []
    if not current:
        default_hubs = ["ZTL_CTR", "ZMA_CTR", "ZNY_CTR", "ZAU_CTR"]
        return [app_commands.Choice(name=hub, value=hub) for hub in default_hubs]
    
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT DISTINCT callsign FROM controller_snapshots WHERE callsign LIKE ? LIMIT 10", 
            (f"%{current.upper()}%",)
        )
        results = cursor.fetchall()
        conn.close()
        for row in results:
            choices.append(app_commands.Choice(name=row[0], value=row[0]))
    except Exception as e:
        print(f"Autocomplete database error: {e}")
        
    return choices

# A view containing a drop-down menu for instant hub selection
class HubSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.select(
        placeholder="Choose a primary Virtual Airline hub...",
        min_values=1,
        max_values=1,
        options=[
            discord.SelectOption(label="Atlanta Center (ZTL)", value="ZTL_", description="KATL area operations"),
            discord.SelectOption(label="Miami Center (ZMA)", value="ZMA_", description="KMIA area operations"),
            discord.SelectOption(label="New York Center (ZNY)", value="ZNY_", description="KJFK area operations"),
            discord.SelectOption(label="Chicago Center (ZAU)", value="ZAU_", description="KORD area operations")
        ]
    )
    async def select_callback(self, interaction: discord.Interaction, select: discord.ui.Select):
        selected_hub = select.values[0]
        
        now_utc = datetime.now(timezone.utc)
        current_day = now_utc.weekday()
        current_hour = now_utc.hour
        
        await interaction.response.defer()
        
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        cursor.execute('''
            SELECT COUNT(*) FROM global_samples 
            WHERE day_of_week = ? AND hour_of_day = ?
        ''', (current_day, current_hour))
        total_samples = cursor.fetchone()[0]

        if total_samples == 0:
            conn.close()
            await interaction.followup.send(
                f"⚠️ *Insufficient history for current time block (Day {current_day} @ {current_hour:02d}:00z).*",
                ephemeral=True
            )
            return

        cursor.execute('''
            SELECT COUNT(DISTINCT timestamp) FROM controller_snapshots
            WHERE day_of_week = ? 
              AND hour_of_day = ? 
              AND (callsign = ? OR callsign LIKE ?)
        ''', (current_day, current_hour, selected_hub, f"{selected_hub}%"))
        active_samples = cursor.fetchone()[0]
        conn.close()

        probability = (active_samples / total_samples) * 100
        
        embed = discord.Embed(
            title=f"📊 Quick Hub Check: {selected_hub.replace('_', '')}",
            color=discord.Color.green() if probability > 25 else discord.Color.orange(),
            timestamp=datetime.now(timezone.utc)
        )
        embed.add_field(name="🕒 Active Window", value=f"{get_weekday_name(current_day)} @ {current_hour:02d}:00 UTC", inline=True)
        embed.add_field(name="📈 ATC Staffing Odds", value=f"**{probability:.1f}%**", inline=True)
        embed.add_field(name="Metrics Check", value=f"{active_samples} online / {total_samples} total snapshots", inline=False)
        embed.set_footer(text="Virtual Airline Dispatch Analytics Engine")
        
        await interaction.followup.send(embed=embed, ephemeral=True)


# --- SLASH COMMANDS ---

@client.tree.command(name="predict", description="Forecast the staffing probability for a specific VATSIM facility.")
@app_commands.describe(
    facility="Type or select the facility identifier (e.g., ATL_CTR, MIA_)",
    day="Day of the week (0=Mon, 1=Tue, 2=Wed, 3=Thu, 4=Fri, 5=Sat, 6=Sun)",
    hour_utc="The target hour in UTC (0 to 23)"
)
@app_commands.autocomplete(facility=facility_autocomplete)
async def predict(interaction: discord.Interaction, facility: str, day: int, hour_utc: int):
    if not (0 <= day <= 6):
        await interaction.response.send_message("❌ Error: Day must be an integer between 0 (Monday) and 6 (Sunday).", ephemeral=True)
        return
    if not (0 <= hour_utc <= 23):
        await interaction.response.send_message("❌ Error: Hour must be an integer between 0 and 23 UTC.", ephemeral=True)
        return

    facility_query = facility.upper().strip()
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute('''
        SELECT COUNT(*) FROM global_samples 
        WHERE day_of_week = ? AND hour_of_day = ?
    ''', (day, hour_utc))
    total_samples = cursor.fetchone()[0]

    if total_samples == 0:
        conn.close()
        await interaction.response.send_message(
            f"📊 **VATSIM Coverage Forecast**\n"
            f"Target: `{facility_query}` | {get_weekday_name(day)} @ {hour_utc:02d}:00z\n"
            f"⚠️ *Insufficient metrics matching this time window. Let the aggregator run longer!*",
            ephemeral=False
        )
        return

    cursor.execute('''
        SELECT COUNT(DISTINCT timestamp) FROM controller_snapshots
        WHERE day_of_week = ? 
          AND hour_of_day = ? 
          AND (callsign = ? OR callsign LIKE ?)
    ''', (day, hour_utc, facility_query, f"{facility_query}%"))
    active_samples = cursor.fetchone()[0]
    conn.close()

    probability = (active_samples / total_samples) * 100

    embed = discord.Embed(
        title="✈️ VATSIM Staffing Forecast Engine",
        color=discord.Color.blue() if probability > 25 else discord.Color.orange(),
        timestamp=datetime.now(timezone.utc)
    )
    embed.add_field(name="Target Station/Prefix", value=f"`{facility_query}`", inline=True)
    embed.add_field(name="Target Window", value=f"{get_weekday_name(day)}s at {hour_utc:02d}:00 UTC", inline=True)
    embed.add_field(name="Historical Probability", value=f"**{probability:.1f}%**", inline=False)
    
    embed.add_field(name="Data Points Analyzed", value=f"{active_samples} online / {total_samples} total logs", inline=True)
    embed.set_footer(text="Virtual Airline Dispatch Analytics Engine")

    await interaction.response.send_message(embed=embed)


@client.tree.command(name="top_atc", description="View a leaderboard of the most active VATSIM facilities tracked.")
async def top_atc(interaction: discord.Interaction):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM global_samples")
    total_global_samples = cursor.fetchone()[0]

    if total_global_samples == 0:
        conn.close()
        await interaction.response.send_message("⚠️ Analytics database is empty. Waiting for background data aggregator loops...", ephemeral=True)
        return

    cursor.execute('''
        SELECT callsign, COUNT(DISTINCT timestamp) as total_seen 
        FROM controller_snapshots
        GROUP BY callsign
        ORDER BY total_seen DESC
        LIMIT 10
    ''')
    top_facilities = cursor.fetchall()
    conn.close()

    embed = discord.Embed(
        title="🔥 Top 10 Monitored VATSIM Facilities",
        description="The most consistently staffed positions across total database observations.",
        color=discord.Color.dark_green(),
        timestamp=datetime.now(timezone.utc)
    )

    leaderboard_text = ""
    for index, (callsign, total_seen) in enumerate(top_facilities, start=1):
        global_frequency = (total_seen / total_global_samples) * 100
        leaderboard_text += f"**{index}. `{callsign}`** — {global_frequency:.1f}% global availability ({total_seen} logs)\n"

    if not leaderboard_text:
        leaderboard_text = "*No staffing snapshot patterns recorded yet.*"

    embed.add_field(name="Network Hotspots Leaderboard", value=leaderboard_text, inline=False)
    embed.set_footer(text=f"Based on {total_global_samples} unique interval checks.")

    await interaction.response.send_message(embed=embed)


@client.tree.command(name="hubs", description="Display interactive drop-down picker for primary flight operations centers.")
async def hubs(interaction: discord.Interaction):
    view = HubSelectView()
    await interaction.response.send_message("🎛️ **Select an operation center to check immediate staffing projections:**", view=view)


@client.tree.command(name="route_check", description="Check the ATC staffing probability along a route between two airports anywhere globally.")
@app_commands.describe(
    origin="Departure ICAO (e.g., KJFK, EGLL, YSSY)",
    destination="Arrival ICAO (e.g., KATL, EDDF, NZAA)",
    day="Day of the week (0=Mon, 1=Tue... 6=Sun)",
    hour_utc="The target hour in UTC (0 to 23)"
)
async def route_check(interaction: discord.Interaction, origin: str, destination: str, day: int, hour_utc: int):
    origin = origin.upper().strip()
    destination = destination.upper().strip()
    
    # Resolves Departure & Arrival FIR/ARTCC prefixes automatically worldwide
    facilities_to_check = []
    if len(origin) >= 4 and len(destination) >= 4:
        dep_prefix = get_global_vatsim_prefix(origin)
        arr_prefix = get_global_vatsim_prefix(destination)
        
        if dep_prefix:
            facilities_to_check.append(dep_prefix)
        if arr_prefix and arr_prefix != dep_prefix:
            facilities_to_check.append(arr_prefix)

    await interaction.response.defer()
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    embed = discord.Embed(
        title=f"🛫 Worldwide Route Staffing Forecast: {origin} ➔ {destination}",
        color=discord.Color.blue(),
        timestamp=datetime.now(timezone.utc)
    )
    
    cursor.execute('''
        SELECT COUNT(*) FROM global_samples 
        WHERE day_of_week = ? AND hour_of_day = ?
          AND timestamp >= datetime('now', '-30 days')
    ''', (day, hour_utc))
    total_samples = cursor.fetchone()[0]
    
    if total_samples == 0:
        embed.description = "⚠️ Insufficient coverage data for this specific UTC time window worldwide."
        embed.color = discord.Color.orange()
    else:
        overall_lowest_prob = 100.0
        
        for fac in facilities_to_check:
            cursor.execute('''
                SELECT COUNT(DISTINCT timestamp) FROM controller_snapshots
                WHERE day_of_week = 1 
                  AND hour_of_day = 12 
                  AND callsign LIKE ?
                  AND timestamp >= datetime('now', '-30 days')
            ''', (f"{fac}%",))
            active_samples = cursor.fetchone()[0]
            
            prob = (active_samples / total_samples) * 100 if total_samples > 0 else 0.0
            overall_lowest_prob = min(overall_lowest_prob, prob)
            
            if fac.startswith('Z') or fac.startswith('CZ') or fac.startswith('HNL'):
                label = "ARTCC Center"
            else:
                label = "FIR Enroute Control"
            
            embed.add_field(
                name=f"Enroute Facility Prefix: `{fac}` ({label})", 
                value=f"Coverage Probability: **{prob:.1f}%** ({active_samples}/{total_samples} samples)", 
                inline=False
            )
        
        embed.add_field(
            name="End-to-End Trip Feasibility", 
            value=f"**{overall_lowest_prob:.1f}%** chance of complete ATC coverage along the route.", 
            inline=False
        )
        
        if overall_lowest_prob < 30.0:
            embed.color = discord.Color.red()
        elif overall_lowest_prob < 70.0:
            embed.color = discord.Color.orange()
        else:
            embed.color = discord.Color.green()

    conn.close()
    
    embed.set_footer(text="Global Virtual Airline Dispatch Analytics Engine")
    await interaction.followup.send(embed=embed)


# --- FEATURE 4: CONTROLLER STAFFING ALERTS (USER SUBSCRIBED DM) ---
alert_subscriptions = {}

@client.tree.command(name="alert_me", description="Get a DM when a specific facility prefix comes online.")
@app_commands.describe(
    facility_prefix="The facility prefix to track (e.g., ZNY, ZTL, EGTT)"
)
async def alert_me(interaction: discord.Interaction, facility_prefix: str):
    prefix = facility_prefix.upper().strip()
    user_id = interaction.user.id
    
    if prefix not in alert_subscriptions:
        alert_subscriptions[prefix] = []
        
    if user_id not in alert_subscriptions[prefix]:
        alert_subscriptions[prefix].append(user_id)
        await interaction.response.send_message(
            f"🔔 Success! You will be direct messaged the next time **`{prefix}`** is logged as online/staffed.",
            ephemeral=True
        )
    else:
        alert_subscriptions[prefix].remove(user_id)
        await interaction.response.send_message(
            f"🔕 You have unsubscribed from alerts for **`{prefix}`**.",
            ephemeral=True
        )


# --- FEATURE 2: USER-SUBSCRIBED DAILY ATC SUMMARY ---

@client.tree.command(name="daily_summary_subscribe", description="Subscribe or unsubscribe to receive the Daily VATSIM Staffing Summary via DM.")
async def daily_summary_subscribe(interaction: discord.Interaction):
    user_id = interaction.user.id
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("SELECT 1 FROM summary_subscriptions WHERE user_id = ?", (user_id,))
    exists = cursor.fetchone()
    
    if exists:
        cursor.execute("DELETE FROM summary_subscriptions WHERE user_id = ?", (user_id,))
        conn.commit()
        conn.close()
        await interaction.response.send_message("🔕 You have unsubscribed from the Daily VATSIM Staffing Summary. You will no longer receive it.", ephemeral=True)
    else:
        cursor.execute("INSERT OR REPLACE INTO summary_subscriptions (user_id) VALUES (?)", (user_id,))
        conn.commit()
        conn.close()
        await interaction.response.send_message("🔔 Success! You are now subscribed to the Daily VATSIM Staffing Summary. You will receive it via Direct Message (DM) daily.", ephemeral=True)


@tasks.loop(hours=24)
async def daily_atc_summary(): # <--- ADDED 'async' HERE
    async def send_dm_reports():
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM global_samples")
        total_global_samples = cursor.fetchone()[0]
        
        if total_global_samples > 0:
            cursor.execute('''
                SELECT callsign, COUNT(DISTINCT timestamp) as total_seen 
                FROM controller_snapshots
                GROUP BY callsign
                ORDER BY total_seen DESC
                LIMIT 5
            ''')
            top_facilities = cursor.fetchall()
            
            cursor.execute("SELECT user_id FROM summary_subscriptions")
            subscribers = cursor.fetchall()
            
            if subscribers:
                embed = discord.Embed(
                    title="📅 Daily VATSIM Staffing Summary",
                    description="Top 5 most active facilities over the trailing aggregation period.",
                    color=discord.Color.gold(),
                    timestamp=datetime.now(timezone.utc)
                )
                
                summary_text = ""
                for index, (callsign, total_seen) in enumerate(top_facilities, start=1):
                    frequency = (total_seen / total_global_samples) * 100
                    summary_text += f"**{index}. `{callsign}`** — {frequency:.1f}% uptime ({total_seen} logs)\n"
                    
                embed.add_field(name="Network Hotspots", value=summary_text, inline=False)
                
                # Direct Messages the summary to all users subscribed in the DB
                for (user_id,) in subscribers:
                    try:
                        user = await client.fetch_user(user_id)
                        if user:
                            await user.send(embed=embed)
                    except Exception as e:
                        print(f"Could not DM summary to user {user_id}: {e}")
                        
        conn.close()
        
    await send_dm_reports()

@daily_atc_summary.before_loop
async def before_daily_summary():
    await client.wait_until_ready()


if __name__ == "__main__":
    if not BOT_TOKEN:
        print("CRITICAL RUNTIME ERROR: DISCORD_TOKEN environmental variable not found!")
        print("Ensure you have a '.env' file containing your credentials in the root directory.")
    else:
        client.run(BOT_TOKEN)