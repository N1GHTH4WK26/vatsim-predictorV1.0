\# ✈️ VATSIM Staffing Coverage Predictor



An automated data-collection and predictive analytics engine designed for Virtual Airlines and flight simulation communities to forecast VATSIM Air Traffic Control (ATC) staffing probabilities. 



Once deployed, your community can use modern Discord slash commands to see historical staffing percentages for any facility based on the day of the week and UTC time block.



\---



\## 📌 Prerequisites (What you need before starting)



Before you install anything, make sure you have the following ready:

1\. \*\*A Desktop PC or Server\*\* running Windows, Mac, or Linux that stays powered on 24/7 (if you want continuous data collection).

2\. \*\*Python 3.8 or Higher\*\* installed on your machine.

3\. \*\*A Discord Account\*\* with "Administrator" permissions in the server where you want to add the bot.



\---



\## 🛠️ Step-by-Step Setup Guide



Follow these steps in order to get your analytics engine running from scratch:



\### Step 1: Install Python Dependencies

Open your computer's command prompt (cmd) or terminal, navigate to your project folder, and run the following command to install the required code libraries:

```bash

pip install -r requirements.txt

Step 2: Create Your Discord Bot \& Get a Token

You need to register the bot with Discord to get an access key (Token):



Go to the Discord Developer Portal and log in.



Click the blue New Application button in the top right. Name it something like VATSIM Predictor and save.



On the left menu, click Bot.



Click Reset Token, confirm it, and click Copy. Save this massive string of numbers and letters somewhere safe—this is your bot's password.



Scroll down on that same Bot page to the Privileged Gateway Intents section.



Turn ON the toggle for Message Content Intent (and click save changes at the bottom).



Step 3: Configure Your Environment Credentials

Look inside your project folder and locate the file named .env.example.



Rename the file to exactly .env (remove the .example part completely).



Open the .env file with Notepad or any text editor.



Replace YOUR\_DISCORD\_BOT\_TOKEN\_HERE with the token you copied in Step 2. It should look like this:



Plaintext

DISCORD\_TOKEN=MTA4MzM0...your.copied.token.here...

Save and close the file.



Step 4: Invite the Bot to Your Server

Go back to the Discord Developer Portal and select your application.



On the left menu, click OAuth2, then click URL Generator.



Under the Scopes column, check the box for bot and applications.commands.



A new section called Bot Permissions will appear below. Check the boxes for:



Send Messages



Embed Links



Copy the long generated URL at the very bottom of the page.



Paste that link into your web browser, select your Discord server, and click Authorize.



Step 5: Launch the Engine

To start tracking data and utilizing commands, you must run both scripts simultaneously.



Option A (Windows Automation): Double-click the included Run\_VA\_Bot.bat file. It will automatically open two background windows—one for data gathering and one for your Discord interface.



Option B (Manual Command Line): Open two separate terminal windows in your project folder and run:



Terminal 1: python collector.py



Terminal 2: python bot.py



🤖 Available Discord Commands

Once the bot shows as "Online" in your server, use these slash commands in any text channel:



/predict — Forecasts the percentage likelihood of an ATC facility being staffed.



Parameters: facility (e.g., ZTL\_ or ATL\_CTR), day (0 for Monday, 6 for Sunday), hour\_utc (0 to 23).



/top\_atc — Renders a leaderboard showing the top 10 most active or frequently staffed control facilities across your local database history.



💡 Important Note on Data

When you first start the bot, your database file (vatsim\_coverage.db) is empty. The backend collector checks the global VATSIM feeds every 2 minutes. Your predictions and percentages will become deeply accurate after a few days of background tracking!



📬 Support \& Contact

If you run into issues during deployment, have technical questions, or need assistance setting up your environment configuration, please reach out via email:



Email: N1GHTH4WK17@icloud.com



⚖️ Attribution \& Licensing

This project is open-source and distributed under the MIT License.



🛑 Mandatory Credit Disclaimer:

You are completely free to download, modify, fork, and use this bot for your Virtual Airline or local community servers. However, proper attribution is required. If you host a modified version of this software, display its code publicly, or redistribute it, you must retain the original developer credit (N1GHTH4WK) within the source files and documentation.



This software is provided "as is" without warranty of any kind. The authors are not liable for any claims, damages, or hosting server performance locks.

